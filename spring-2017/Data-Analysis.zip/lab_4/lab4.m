function lab4()
    syms x;
    f(x)=atan(x);
    
end