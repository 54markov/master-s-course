function lab2()
    a = input('Input first sin frequency: ');
    b = input('Input second sin frequency: ');
    c = input('Input third sin frequency: ');
    
    maxFrequency = max([a b c]);

    Fs = 1000;                    % Sampling frequency
    T = 1/Fs;                     % Sample time
    L = 1000;                     % Length of signal
    t = (0:L-1)*T;                % Time vector

    x = sin(2*pi*a*t) + 2*sin(2*pi*b*t) + 1.5*sin(2*pi*c*t);
    subplot(3, 2, 1), plot(Fs*t, x, 'b');
    xlabel('Time, milliseconds');
    ylabel('Amplitude');
    title('S(t) = sin(a*t)+2*sin(b*t)+1.5*sin(c*t)');
    
    NFFT = 2^nextpow2(L); % Next power of 2 from length of y
    Y = fft(x, NFFT)/L;
    f = Fs/2*linspace(0,1,NFFT/2);
    
    % Plot single-sided amplitude spectrum.
    subplot(3, 2, 3), stem(f, 2*abs(Y(1:NFFT/2)), 'b');
    hold on;
    subplot(3, 2, 3), stem(-f, -2*abs(Y(1:NFFT/2)), 'b');
    
    xlim([-maxFrequency*2 maxFrequency*2]);
    xlabel('Frequency, Hz');
    ylabel('fft(S, frequency)');
    title('FFT S(frequency)');
    
    subplot(3, 2, 5), plot(Fs*t, ifft2(fft2(x)), 'b');
    xlim([0 Fs]);
    ylim(y_lims(x));
    xlabel('Time, milliseconds');
    ylabel('ifft(S, time)');
    title('IFFT S(time)');
    
    %*********************************************************************%

    Fs1 = 1000;                    % Sampling frequency
    T1 = 1/Fs1;                    % Sample time
    L1 = 1000;                     % Length of signal
    t1 = (0:L1-1)*T1;              % Time vector
    
    x1 = x + randn(size(t1)) + 0.1;

    subplot(3, 2, 2), plot(Fs*t, x, 'b');
    hold on;
    subplot(3, 2, 2), plot(Fs1*t1, x1, 'r');
    xlabel('Time, milliseconds');
    ylabel('Amplitude');
    title('S1(t) = S(t) + randn(size(time)) + 0.1');
    
    NFFT1 = 2^nextpow2(L1); % Next power of 2 from length of y
    Y1 = fft(x1, NFFT1)/L1;
    f1 = Fs1/2*linspace(0, 1, NFFT1/2);
    
    % Plot single-sided amplitude spectrum.
    subplot(3, 2, 4), stem(f, 2*abs(Y(1:NFFT/2)), 'b');
    hold on;
    subplot(3, 2, 4), stem(-f, -2*abs(Y(1:NFFT/2)), 'b');
    hold on;
    subplot(3, 2, 4), stem(f1, 2*abs(Y1(1:NFFT1/2)), 'r');
    hold on;
    subplot(3, 2, 4), stem(-f1, -2*abs(Y1(1:NFFT1/2)), 'r');

    xlim([-maxFrequency*2 maxFrequency*2]);
    xlabel('Frequency, Hz');
    ylabel('fft(S1, frequency)');
    title('FFT S1(frequency)');
    
    subplot(3, 2, 6), plot(Fs*t, ifft2(fft2(x)), 'b');
    hold on;
    subplot(3, 2, 6), plot(Fs1*t1, ifft2(fft2(x1)), 'r');
    xlim([0 Fs1]);
    ylim(y_lims(x1));
    xlabel('Time, milliseconds');
    ylabel('ifft(S, time)');
    title('IFFT S(time)');    
end

function ylims = y_lims(signal)
    s_max = max(signal);
    s_min = min(signal);
    range = s_max-s_min;
    if(range == 0)
        y_min = s_max-s_max;
        y_max = s_max+s_max;
    else
        y_min = s_max - range*1.05;
        y_max = s_min + range*1.05;
    end
    ylims = [y_min y_max];
end