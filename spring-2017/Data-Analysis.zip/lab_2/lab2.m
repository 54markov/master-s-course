% ����� ��� ��������
% s(t) = sin(a*time)+2*sin(b*time)+1.5*sin(c*time)
% a, b � c �������� � ����������
    
function lab2()
    a = input('������� ������� ������ ���������: ');
    b = input('������� ������� ������ ���������: ');
    c = input('������� ������� ������� ���������: ');
    mode = input('sublop/plot (1/0): ');

    col          = 'b';
    maxFrequency = max([a b c]);
    Fs           = maxFrequency*2 + 1;
    Tm           = 1024;
    T            = 1/min([a b c]);
    time         = 0:1/Fs:Tm;

    if (mode == 0) %plot
        draw_orig(a, b, c, time, 'b', 1);
        draw_orig_fft(a, b, c, time, 'b', 2);
        draw_orig_ifft(a, b, c, time, '--b', 3);

        draw_noice(a, b, c, time, 'r', 4);
        draw_noice_fft(a, b, c, time, 'r', 5);
        draw_noice_ifft(a, b, c, time, '--r', 6);
    else % subplot
        draw(a, b, c, time);      
    end
end

function draw(a, b, c, time)
    maxFrequency = max([a b c]);

    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);

    subplot(3,2,1), plot(time, signal, 'b');
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal));
    xlabel('Time, seconds');
    ylabel('Amplitude');
    title(['Graph original S(t) = sin(' num2str(a) '*t)+2*sin(' num2str(b) '*t)+1.5*sin(' num2str(c) '*t)']);
    grid on;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   
    signal1 = signal + randn(size(time)) + 0.1;

    subplot(3,2,2), plot(time, signal, 'b');
    hold on;
    subplot(3,2,2), plot(time, signal1, 'r');
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal1));

    xlabel('Time, seconds');
    ylabel('Amplitude');
    title('Graph noice S1(t) = S(t) + rand(0.1)');
    grid on;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    maxFrequency = max([a b c]);

    Fs           = maxFrequency*2 + 1;
    Tm           = 1024;
    
    signal = sin(a*2*pi*time)+2*sin(b*2*pi*time)+1.5*sin(c*2*pi*time);

    % ��������������
    NFFT      = Fs*Tm; 
    FFT_res   = fft(signal, NFFT);  
    FFT_res   = FFT_res./NFFT;
    FFT_res   = fftshift(FFT_res);
    
    frequency =-Fs/2:Fs/NFFT:Fs/2-Fs/NFFT;
    
    frequency = frequency((end/2):end);
    FFT_res = FFT_res((end/2):end);
    
    % ������ ������������ �������
    amplitude_spectrum1 = abs(FFT_res);
    amplitude_spectrum1 = amplitude_spectrum1./max(amplitude_spectrum1);

    subplot(3,2,3), plot(frequency, amplitude_spectrum1, 'b');
    hold on;
    subplot(3,2,3), plot(-frequency, -amplitude_spectrum1, 'b');

    xlim([-maxFrequency*1.1 maxFrequency*1.1]);
    lims_by_y = y_lims(amplitude_spectrum1./max(amplitude_spectrum1));
    ylim([-1.2*lims_by_y(2) 1.2*lims_by_y(2)]);

    xlabel('Frequency, Hz');
    ylabel('fft(S, frequency)');
    title('Graph original FFT (S,frequency)');
    grid on;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    maxFrequency = max([a b c]);

    Fs           = maxFrequency*2 + 1;
    Tm           = 1024;
    
    signal = sin(a*2*pi*time)+2*sin(b*2*pi*time)+1.5*sin(c*2*pi*time);
    signal = signal + randn(size(time)) + 0.1;

    % ��������������
    NFFT      = Fs*Tm; 
    FFT_res   = fft(signal, NFFT);  
    FFT_res   = FFT_res./NFFT;
    FFT_res   = fftshift(FFT_res);
    
    frequency1 =-Fs/2:Fs/NFFT:Fs/2-Fs/NFFT;
    
    frequency1 = frequency1((end/2):end);
    FFT_res = FFT_res((end/2):end);
    
    % ������ ������������ �������
    amplitude_spectrum = abs(FFT_res);
    amplitude_spectrum = amplitude_spectrum./max(amplitude_spectrum);

    subplot(3,2,4), plot(frequency, amplitude_spectrum1, 'b');
    hold on;
    subplot(3,2,4), plot(-frequency, -amplitude_spectrum1, 'b');
    hold on;
    subplot(3,2,4), plot(frequency1, amplitude_spectrum, 'r');
    hold on;
    subplot(3,2,4), plot(-frequency1, -amplitude_spectrum, 'r');

    xlim([-maxFrequency*1.1 maxFrequency*1.1]);
    lims_by_y = y_lims(amplitude_spectrum./max(amplitude_spectrum));
    ylim([-1.2*lims_by_y(2) 1.2*lims_by_y(2)]);

    xlabel('Frequency, Hz');
    ylabel('fft(S1, frequency)');
    title('Graph original FFT S1(frequency)');
    grid on;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    maxFrequency = max([a b c]);
    Fs           = maxFrequency*2 + 1;
    
    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);
   
    subplot(3,2,5),  plot(time, ifft2(fft2(signal)), 'b');
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal));

    xlabel('Time, seconds');
    ylabel('ifft(S, time)');
    title('Graph original IFFT(S(t))');
    grid on;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    maxFrequency = max([a b c]);
    Fs           = maxFrequency*2 + 1;
    
    signal1 = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);
    signal1 = signal1 + randn(size(time)) + 0.1;

    subplot(3, 2, 6), plot(time, ifft2(fft2(signal)), 'b');
    hold on;
    subplot(3, 2, 6), plot(time, ifft2(fft2(signal1)), 'r');
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal1));

    xlabel('Time, seconds');
    ylabel('ifft(S1, time)');
    title('Graph noice ifft(S1(t))');
    grid on;
end

function draw_orig(a, b, c, time, col, num)
    maxFrequency = max([a b c]);

    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);

    figure(num), plot(time, signal, col);
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal));

    xlabel('Time, seconds');
    ylabel('Amplitude');
    title(['Graph original S(t) = sin(' num2str(a) '*t)+2*sin(' num2str(b) '*t)+1.5*sin(' num2str(c) '*t)']);
    grid on;
end

function draw_orig_fft(a, b, c, time, col, num)
    maxFrequency = max([a b c]);

    Fs           = maxFrequency*2 + 1;
    Tm           = 1024;
    
    signal = sin(a*2*pi*time)+2*sin(b*2*pi*time)+1.5*sin(c*2*pi*time);

    % ��������������
    NFFT      = Fs*Tm; 
    FFT_res   = fft(signal, NFFT);  
    FFT_res   = FFT_res./NFFT;
    FFT_res   = fftshift(FFT_res);
    
    frequency1 =-Fs/2:Fs/NFFT:Fs/2-Fs/NFFT;
    
    frequency1 = frequency1((end/2):end);
    FFT_res = FFT_res((end/2):end);
    
    % ������ ������������ �������
    amplitude_spectrum = abs(FFT_res);
    amplitude_spectrum = amplitude_spectrum./max(amplitude_spectrum);

    figure(num), plot(frequency1, amplitude_spectrum, col);
    hold on;
    figure(num), plot(-frequency1, -amplitude_spectrum, col);

    xlim([-maxFrequency*1.1 maxFrequency*1.1]);
    lims_by_y = y_lims(amplitude_spectrum./max(amplitude_spectrum));
    ylim([-1.2*lims_by_y(2) 1.2*lims_by_y(2)]);

    xlabel('Frequency, Hz');
    ylabel('fft(S1, frequency)');
    title('Graph original FFT S1(frequency)');
    grid on;
end

function draw_orig_ifft(a, b, c, time, col, num)
    maxFrequency = max([a b c]);
    Fs           = maxFrequency*2 + 1;
    
    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);
   
    figure(num),  plot(time, ifft2(fft2(signal)), col);
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal));

    xlabel('Time, seconds');
    ylabel('ifft(S, time)');
    title('Graph original IFFT(S(t))');
    grid on;
end

function draw_noice(a, b, c, time, col, num)
    maxFrequency = max([a b c]);

    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);
    signal = signal + randn(size(time)) + 0.1;

    figure(num), plot(time, signal, col);
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 30*pi/maxFrequency]);
    end
    ylim(y_lims(signal));

    xlabel('Time, seconds');
    ylabel('Amplitude');
    title('Graph noice');
    legend(['S1(t) = S(t) + rand(0.1)']);
    grid on;
end

function draw_noice_fft(a, b, c, time, col, num)
    maxFrequency = max([a b c]);

    Fs           = maxFrequency*2 + 1;
    Tm           = 1024;
    
    signal = sin(a*2*pi*time)+2*sin(b*2*pi*time)+1.5*sin(c*2*pi*time);
    signal = signal + randn(size(time)) + 0.1;

    % ��������������
    NFFT      = Fs*Tm; 
    FFT_res   = fft(signal, NFFT);  
    FFT_res   = FFT_res./NFFT;
    FFT_res   = fftshift(FFT_res);
    
    frequency1 =-Fs/2:Fs/NFFT:Fs/2-Fs/NFFT;
    
    frequency1 = frequency1((end/2):end);
    FFT_res = FFT_res((end/2):end);
    
    % ������ ������������ �������
    amplitude_spectrum = abs(FFT_res);
    amplitude_spectrum = amplitude_spectrum./max(amplitude_spectrum);

    figure(num), plot(frequency1, amplitude_spectrum, col);
    hold on;
    figure(num), plot(-frequency1, -amplitude_spectrum, col);

    xlim([-maxFrequency*1.1 maxFrequency*1.1]);
    lims_by_y = y_lims(amplitude_spectrum./max(amplitude_spectrum));
    ylim([-1.2*lims_by_y(2) 1.2*lims_by_y(2)]);

    xlabel('Frequency, Hz');
    ylabel('fft(S1, frequency)');
    title('Graph original FFT S1(frequency)');
    grid on;
end

function draw_noice_ifft(a, b, c, time, col, num)
    maxFrequency = max([a b c]);
    Fs           = maxFrequency*2 + 1;
    
    signal = sin(a*time)+2*sin(b*time)+1.5*sin(c*time);
    signal = signal + randn(size(time)) + 0.1;

    figure(num), plot(time, ifft2(fft2(signal)), col);
    
    if (maxFrequency < 10)
        xlim([0 10*pi/maxFrequency]);
    else
        xlim([0 100*pi/maxFrequency]);
    end
    ylim(y_lims(signal));

    xlabel('Time, seconds');
    ylabel('ifft(S1, time)');
    title('Graph noice ifft(S1(t))');
    legend('ifft(S1(t))');
    axis square;
    grid on;
end

function ylims = y_lims(signal)
    s_max = max(signal);
    s_min = min(signal);
    range = s_max-s_min;
    if(range == 0)
        y_min = s_max-s_max;
        y_max = s_max+s_max;
    else
        y_min = s_max - range*1.05;
        y_max = s_min + range*1.05;
    end
    ylims = [y_min y_max];
end
