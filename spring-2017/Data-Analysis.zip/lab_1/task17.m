function task17()
    fig=input('Input object name [cube/cone]: ','s');
    if (strcmp(fig,'cube'))
        n=input('Input N: ');
        x=[0 1 1 0 0 0;1 1 0 0 1 1;1 1 0 0 1 1;0 1 1 0 0 0]*n;
        y=[0 0 1 1 0 0;0 1 1 0 0 0;0 1 1 0 1 1;0 0 1 1 1 1]*n;
        z=[0 0 0 0 0 1;0 0 0 0 0 1;1 1 1 1 0 1;1 1 1 1 0 1]*n;
        plot3(x,y,z)
    elseif (strcmp(fig,'cone'))
        h=input('Input h: ');
        r=input('Input r: ');
        m = h/r;
        [R,A] = meshgrid(linspace(0, r, 20), linspace(0,2*pi,41));
        X = R .* cos(A);
        Y = R .* sin(A);
        Z = m*R;
        % Cone around the z-axis, point at the origin
        mesh(Z,X,Y)
    end
    
        n=5
        x=[0 1 1 0 0 0;1 1 0 0 1 1;1 1 0 0 1 1;0 1 1 0 0 0]*n;
        y=[0 0 1 1 0 0;0 1 1 0 0 0;0 1 1 0 1 1;0 0 1 1 1 1]*n;
        z=[0 0 0 0 0 1;0 0 0 0 0 1;1 1 1 1 0 1;1 1 1 1 0 1]*n;
        subplot(2, 1, 1), plot3(x,y,z)
        h=5
        r=5
        m = h/r;
        [R,A] = meshgrid(linspace(0, r, 20), linspace(0,2*pi,41));
        X = R .* cos(A);
        Y = R .* sin(A);
        Z = m*R;
        % Cone around the z-axis, point at the origin
        subplot(2, 1, 2), mesh(Z,X,Y)
end