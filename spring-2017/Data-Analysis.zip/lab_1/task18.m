function task18()
    GREEN=0;
    RED=0;
    BLUE=0;
    fig=input('Input object name [red/green/blue]: ','s');
    if (strcmp(fig,'red'))
        RED=1;
    elseif (strcmp(fig,'green'))
        GREEN=1;
    elseif (strcmp(fig,'blue'))
       BLUE=1; 
    end

    rgbImage = imread('E:\study\2 �������\������ ������\lab_1\pic.jpg');

    % Enlarge figure to full screen.
    set(gcf, 'Position', get(0,'Screensize')); 
    % Here's where the real meat of the code begins:
    % Extract the individual red, green, and blue color channels.
    redChannel   = rgbImage(:, :, 1);
    greenChannel = rgbImage(:, :, 2);
    blueChannel  = rgbImage(:, :, 3);
    
    % Construct the rgb image with swapped red and green channels.
    rgbImageR = cat(3, redChannel*1, greenChannel*0, blueChannel*0);
    rgbImageG = cat(3, redChannel*0, greenChannel*1, blueChannel*0);
    rgbImageB = cat(3, redChannel*0, greenChannel*0, blueChannel*1);
    % Display the new color image.
    subplot(1, 3, 1), imshow(rgbImageG);
    subplot(1, 3, 2), imshow(rgbImageR);
    subplot(1, 3, 3), imshow(rgbImageB);
end