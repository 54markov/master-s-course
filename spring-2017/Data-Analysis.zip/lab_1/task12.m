function task12()
    xmin = fminbnd('(x+2)*(x-4)',-80,80)
    xmax = fminbnd('-(x+2)*(x-4)',-80,80)
    ymin = (xmin+2)*(xmin-4)
    ymax = (xmax+2)*(xmax-4)
    X=-80:1:80;
    Y=(X+2).*(X-4);
    plot(X, Y, xmin, (xmin+2).*(xmin-4), 'ko', xmax, (xmax+2).*(xmax-4), 'ko','LineWidth',1,'MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',5);
    title('������� 2. ��������� �������')
    legend('y=(x+2)*(�-4)')
    xlabel('x')
    ylabel('y')
    text(xmin+3, -210,'Amin (1, -9)','FontSize',10);
    text(xmax+3, 6550,'Bmax (-80, 6550)','FontSize',10);
    grid;
    axis square;
end