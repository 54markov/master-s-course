function task16()
    fig=input('Input object name [sphere/pyramid]: ','s');
    if (strcmp(fig,'sphere'))
        r=input('Input R: ');
        [x,y,z] = sphere();
        mesh(x*r,y*r,z*r);
        alpha .2
    elseif (strcmp(fig,'pyramid'))
        h=input('Input h: ');
        l=input('Input l: ');
        x = [0 0 0 0; l l -l l; l -l -l -l];
        y = [0 0 0 0; h h h h; h h h h]; 
        z = [0 0 0 0; l l -l -l; -l l l -l];
        fill3(x,y,z, ones(3,4))
        alpha(.5)
    end
    
    r=5;
    [xs,ys,zs] = sphere();
    %mesh(x*r,y*r,z*r);
    %alpha .2
    
    h=5;
    l=5;
    xp = [0 0 0 0; l l -l l; l -l -l -l];
    yp = [0 0 0 0; h h h h; h h h h]; 
    zp = [0 0 0 0; l l -l -l; -l l l -l];
    %fill3(x,y,z, ones(3,4))
    %alpha .2
    
    subplot(2,1,1), mesh(xs*r,ys*r,zs*r), alpha .2;
    subplot(2,1,2), fill3(xp,yp,zp, ones(3,4)), alpha .2;
end