function task14()
    x1=0;
    y1=0;
    x2=3;
    y2=0;
    x3=3;
    y3=10;
    
    xc = (x3 + x1)/2
    yc = (y3 + y1)/2
    rc = sqrt((x3 - x1)^2+(y3 - y1)^2);
    rc = rc / 2
    
    % draw main circle
    r = 4;
    X = linspace(x1 - r, x1 + r);
    Y = sqrt(r^2 - (X - x1).^2); 
    plot([X, X(end:-1:1)], [Y + y1, -Y + y1]); 
    hold on;
    % draw sub-circle
    X1 = linspace(xc - rc, xc + rc);
    Y1 = sqrt(rc^2 - (X1 - xc).^2);
    plot([X1, X1(end:-1:1)], [Y1 + yc, -Y1 + yc]), grid on,axis square; 
    hold on;
    
    syms x y
    Y1=(x-x1)^2+(y-y1)^2-4^2 %��������� ����������
    Y2=(x-xc)^2+(y-yc)^2-rc^2 %��������� ���������� 
    p=solve(Y1,Y2) % ����� �����������, ���� ��� ���� 
    if isempty(p) 
        disp('No solve') 
    else
        plot(p.x(2), p.y(2),'ko','MarkerFaceColor','g');
        plot([x1 p.x(2)], [y1 p.y(2)],'r');
        plot([x3 p.x(2)], [y3 p.y(2)],'r');
    end
    
    %dot (3;10)
    plot(x3,y3,'ko','MarkerFaceColor','g');
    %dot (0;0)
    plot(0,0,'ko','MarkerFaceColor','g');
    % line
    xl=[x1 x3];
    yl=[y1 y3];
    plot(xl,yl,'r') 
    xlabel('x');
    ylabel('y');
    axis([-6 11 -6 11]);
    axis square;
    text (0+0.5, 0+0.5,'0');
    text (3+0.5, 10+0.5,'A');
    text (p.x(2)+0.5, p.y(2)+0.5,'B');
end