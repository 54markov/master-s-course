function task11()
    x=-10:15;
    y1=x.^2-5*x+3;
    y2=7*x-4;

    plot(x, y1,'r', x, y2,'b', 0.6148, 0.3038, 'ko', 11.3852, 75.6962, 'ko', 'LineWidth',1,'MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',5);
    title('������� 1. ������ ����������� ������ y1 � y2')
    legend('y1=x^2-5x+3','y2=7x-4')
    xlabel('x')
    ylabel('y')
    grid
    x1=fsolve('x.^2-5*x+3-7*x+4',0,optimset('Display','off'))
    y1=7*x1-4
    x2=fsolve('x.^2-5*x+3-7*x+4',10,optimset('Display','off'))
    y2=7*x2-4
    text(x1, y1 - 10, 'A (0.6148, 0.3038)','FontSize',10);
    text(x2, y2 - 10, 'B (11.3852, 75.6962)','FontSize',10);
end