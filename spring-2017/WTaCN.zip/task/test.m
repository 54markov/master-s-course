function test()

    m  = [3, 5, 7, 9, 11, 13];
    Bm = [8, 32, 128, 512, 2048, 8192];
    h  = 1;
    a  = 0;
    
    for i = 1:6
        q = calc_q(h);
        p = calc_q(h);

        a = log2(m(i)) + q * log2(q)+ p * log2(p./m - 1);
        b = Bm(i)./2;
        a = b./a
    end
    plot(a, m);
end

function[q] = calc_q(h)
    q = 2;
end

function[p] = calc_p(h)
    p = 1 - calc_q(h);
end